using System;

namespace C1
{
    // Node for doubly-linked list (keeps original field names for compatibility)
    public class DLLNode
    {
        public int num;                // value stored
        public DLLNode? next;          // next node
        public DLLNode? previous;      // previous node

        public DLLNode(int num)
        {
            this.num = num;
            this.next = null;
            this.previous = null;
        }

        // Instance method to check whether this node's value is prime
        public bool IsPrime()
        {
            int n = this.num;
            if (n < 2) return false;
            if (n % 2 == 0) return n == 2;
            int r = (int)Math.Sqrt(n);
            for (int i = 3; i <= r; i += 2)
                if (n % i == 0) return false;
            return true;
        }

        // Compatibility: original code had IsPrime(int n)
        public bool IsPrime(int n)
        {
            // If caller passes a number, evaluate that number
            if (n < 2) return false;
            if (n % 2 == 0) return n == 2;
            int r = (int)Math.Sqrt(n);
            for (int i = 3; i <= r; i += 2)
                if (n % i == 0) return false;
            return true;
        }

        // Compatibility properties used by tests
        public int Data { get => num; set => num = value; }
        public DLLNode? Next { get => next; set => next = value; }
        public DLLNode? Prev { get => previous; set => previous = value; }
    }
}
