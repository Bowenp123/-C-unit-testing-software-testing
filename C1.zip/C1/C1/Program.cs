﻿using System;
using System.Diagnostics;

namespace C1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the doubly linked list with errors");
            Console.WriteLine("All bugs have been fixed!");

            // Quick test example
            var list = new DLList();
            list.AddToHead(5);
            list.AddToHead(3);
            list.AddToTail(7);

            Console.WriteLine($"Total sum: {list.Total()}");          // Should be 15
            Console.WriteLine($"Primes count: {list.CountPrimes()}"); // Should be 3

            var found = list.Search(5);
            Console.WriteLine("Search for 5: " + (found != null ? "FOUND" : "NOT FOUND"));

            // Manual test helper removed from startup; use dotnet test or Test Explorer to run tests.

            // Removed automatic dotnet test invocation per request.

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }

        // RunDotnetTests was removed to avoid spawning dotnet when the app starts.
    }
}
