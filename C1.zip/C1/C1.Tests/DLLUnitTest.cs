using Microsoft.VisualStudio.TestTools.UnitTesting;
using C1;
using System.Collections.Generic;
using System.Linq;

namespace C1.Tests
{
    [TestClass]
    public class DLLUnitTest
    {
        // Test 1/22 - Basic operations: add values, check total, prime count, and search
        [TestMethod]
        public void BasicOperations_Test()
        {
            var list = new DLList();
            list.AddToHead(5);
            list.AddToHead(3);
            list.AddToTail(7);

            Assert.AreEqual(15, list.Total());
            Assert.AreEqual(3, list.CountPrimes());

            var found = list.Search(5);
            Assert.IsNotNull(found);
            Assert.AreEqual(5, found!.Data);
        }

        // Test 2/22 - Node creation and Count behavior; also verifies enumeration for single-node list
        [TestMethod]
        public void TestNodeAndCount()
        {
            // Create a node and verify basic properties and list behavior
            var node = new DLLNode(42);
            Assert.IsNotNull(node);
            Assert.AreEqual(42, node.Data);

            var list = new DLList();
            list.AddToHead(node);
            Assert.AreEqual(1, list.Count);

            // Enumeration should yield the single value
            CollectionAssert.AreEqual(new[] { 42 }, new List<int>(list));
        }

        // Test 3/22 - Empty list should have total 0 and Count 0
        [TestMethod]
        public void EmptyList_TotalIsZero()
        {
            var list = new DLList();
            Assert.AreEqual(0, list.Total());
            Assert.AreEqual(0, list.Count);
        }

        // Test 4/22 - Empty list should report zero prime elements
        [TestMethod]
        public void EmptyList_CountPrimesIsZero()
        {
            var list = new DLList();
            Assert.AreEqual(0, list.CountPrimes());
        }

        // Test 5/22 - Searching an empty list returns null
        [TestMethod]
        public void EmptyList_SearchReturnsNull()
        {
            var list = new DLList();
            Assert.IsNull(list.Search(1));
        }

        // Test 6/22 - Single element added to head: verify Count, Total and enumeration order
        [TestMethod]
        public void SingleElement_AddToHead_CountAndTotal()
        {
            var list = new DLList();
            list.AddToHead(7);
            Assert.AreEqual(1, list.Count);
            Assert.AreEqual(7, list.Total());
            CollectionAssert.AreEqual(new[] { 7 }, new List<int>(list));
        }

        // Test 7/22 - Single element added to tail: verify Count, Total and enumeration order
        [TestMethod]
        public void SingleElement_AddToTail_CountAndTotal()
        {
            var list = new DLList();
            list.AddToTail(4);
            Assert.AreEqual(1, list.Count);
            Assert.AreEqual(4, list.Total());
            CollectionAssert.AreEqual(new[] { 4 }, new List<int>(list));
        }

        // Test 8/22 - Multiple adds to head/tail produce expected ordering when enumerated
        [TestMethod]
        public void MultipleAdds_OrderCheck()
        {
            var list = new DLList();
            list.AddToHead(2); // head
            list.AddToTail(3);
            list.AddToHead(1);
            // expected 1,2,3
            CollectionAssert.AreEqual(new[] { 1, 2, 3 }, new List<int>(list));
        }

        // Test 9/22 - Duplicates: Search should find the first occurrence
        [TestMethod]
        public void Duplicates_SearchFindsFirst()
        {
            var list = new DLList();
            list.AddToTail(5);
            list.AddToTail(5);
            var found = list.Search(5);
            Assert.IsNotNull(found);
            Assert.AreEqual(5, found!.Data);
        }

        // Test 10/22 - Negative values: Total sums negatives, negatives are not prime
        [TestMethod]
        public void NegativeValues_TotalAndPrimes()
        {
            var list = new DLList();
            list.AddToTail(-3);
            list.AddToTail(-2);
            Assert.AreEqual(-5, list.Total());
            Assert.AreEqual(0, list.CountPrimes());
        }

        // Test 11/22 - Zero is not considered prime
        [TestMethod]
        public void ZeroIsNotPrime()
        {
            var list = new DLList();
            list.AddToHead(0);
            Assert.AreEqual(0, list.CountPrimes());
        }

        // Test 12/22 - Large prime number should be counted as prime
        [TestMethod]
        public void LargePrime_CountPrimesCountsIt()
        {
            var list = new DLList();
            list.AddToHead(97);
            Assert.AreEqual(1, list.CountPrimes());
        }

        // Test 13/22 - Count property should match enumeration length
        [TestMethod]
        public void CountMatchesEnumeration()
        {
            var list = new DLList();
            list.AddToTail(1);
            list.AddToTail(2);
            list.AddToTail(3);
            Assert.AreEqual(3, list.Count);
            Assert.AreEqual(3, new List<int>(list).Count);
        }

        // Test 14/22 - Adding many elements: Count and Total should be correct
        [TestMethod]
        public void AddMany_CountCorrect()
        {
            var list = new DLList();
            for (int i = 0; i < 20; i++) list.AddToTail(i);
            Assert.AreEqual(20, list.Count);
            Assert.AreEqual((19 * 20) / 2, list.Total());
        }

        // Test 15/22 - Enumeration yields correct sequence after mixed head/tail adds
        [TestMethod]
        public void Enumeration_SequenceAfterMixAdds()
        {
            var list = new DLList();
            list.AddToHead(2);
            list.AddToTail(3);
            list.AddToHead(1);
            var seq = new List<int>(list);
            CollectionAssert.AreEqual(new[] { 1, 2, 3 }, seq);
        }

        // Test 16/22 - Searching for non-existent value returns null
        [TestMethod]
        public void SearchNotFound_ReturnsNull()
        {
            var list = new DLList();
            list.AddToTail(1);
            Assert.IsNull(list.Search(999));
        }

        // Test 17/22 - CountPrimes counts each prime entry, even duplicates
        [TestMethod]
        public void PrimesWithDuplicates_CountPrimesCountsAll()
        {
            var list = new DLList();
            list.AddToTail(2);
            list.AddToTail(3);
            list.AddToTail(3);
            Assert.AreEqual(3, list.CountPrimes());
        }

        // Test 18/22 - Adding distinct node instances with same value should work and not corrupt links
        [TestMethod]
        public void AddDistinctNodes_WithSameValue_BehavesCorrectly()
        {
            var list = new DLList();
            var n1 = new DLLNode(8);
            var n2 = new DLLNode(8);
            list.AddToHead(n1);
            list.AddToTail(n2);
            Assert.AreEqual(2, list.Count);
            CollectionAssert.AreEqual(new[] { 8, 8 }, new List<int>(list));
        }

        // Test 19/22 - Verify last element can be obtained by iterating the list
        [TestMethod]
        public void LastElement_CanBeRetrievedByEnumeration()
        {
            var list = new DLList();
            list.AddToTail(10);
            list.AddToTail(20);
            list.AddToTail(30);
            int last = -1;
            foreach (var v in list) last = v;
            Assert.AreEqual(30, last);
        }

        // Test 20/22 - Total with positive and negative values computes correctly
        [TestMethod]
        public void TotalWithMixedSigns()
        {
            var list = new DLList();
            list.AddToTail(-5);
            list.AddToTail(5);
            list.AddToTail(10);
            Assert.AreEqual(10, list.Total());
        }

        // Test 21/22 - CountPrimes ignores non-prime numbers among primes
        [TestMethod]
        public void CountPrimes_WithOneNonPrime()
        {
            var list = new DLList();
            list.AddToTail(2);
            list.AddToTail(4);
            list.AddToTail(3);
            Assert.AreEqual(2, list.CountPrimes());
        }

        // Test 22/22 - Foreach iteration works via IEnumerable<int> implementation
        [TestMethod]
        public void ForeachWorks_ImplementsIEnumerable()
        {
            var list = new DLList();
            list.AddToTail(1);
            list.AddToTail(2);
            var collected = new List<int>();
            foreach (var v in list) collected.Add(v);
            CollectionAssert.AreEqual(new[] { 1, 2 }, collected);
        }

        // Test 23/23 - Add 100 to head and remove tail using the DLList API
        [TestMethod]
        public void Bowen()
        {
            var list = new DLList();
            // initial list: 1 -> 2 -> 3
            list.AddToTail(1);
            list.AddToTail(2);
            list.AddToTail(3);

            // add 100 to head, then remove original tail (3)
            list.AddToHead(100);
            list.RemoveTail();

            // expect 100 -> 1 -> 2
            //CollectionAssert.AreEqual(new[] { 100, 1, 2 }, new List<int>(list));
            //Assert.AreEqual(3, list.Count);
            Assert.AreEqual(list.tail.Data, 100);
        }
    }
}
